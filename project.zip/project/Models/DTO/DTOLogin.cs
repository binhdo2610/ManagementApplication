﻿namespace project.Models.DTO
{
    public class DTOLogin
    {
        public string Username { get; set; } = String.Empty;
        public string Password { get; set; } = String.Empty;
    }
}
